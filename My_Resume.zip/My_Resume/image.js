let timeline = gsap.timeline();

timeline.to(".image-wrap", {
    height: "500",
    duration: 1.5,
    ease: "power4.inOut",
})